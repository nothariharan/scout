﻿# Scout — Hack-Nation archive

Open START-HERE.md first.

That file explains how to unpack, how to read the codebase, and which docs to open in order.

Live demo: https://scout-dusky-six.vercel.app
GitHub: https://github.com/nothariharan/scout
