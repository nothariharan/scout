(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[663],{3069:function(e,t,n){"use strict";var o,i;e.exports=(null==(o=n.g.process)?void 0:o.env)&&"object"==typeof(null==(i=n.g.process)?void 0:i.env)?n.g.process:n(7030)},7030:function(e){!function(){var t={229:function(e){var t,n,o,i=e.exports={};function s(){throw Error("setTimeout has not been defined")}function a(){throw Error("clearTimeout has not been defined")}function r(e){if(t===setTimeout)return setTimeout(e,0);if((t===s||!t)&&setTimeout)return t=setTimeout,setTimeout(e,0);try{return t(e,0)}catch(n){try{return t.call(null,e,0)}catch(n){return t.call(this,e,0)}}}!function(){try{t="function"==typeof setTimeout?setTimeout:s}catch(e){t=s}try{n="function"==typeof clearTimeout?clearTimeout:a}catch(e){n=a}}();var l=[],c=!1,u=-1;function d(){c&&o&&(c=!1,o.length?l=o.concat(l):u=-1,l.length&&h())}function h(){if(!c){var e=r(d);c=!0;for(var t=l.length;t;){for(o=l,l=[];++u<t;)o&&o[u].run();u=-1,t=l.length}o=null,c=!1,function(e){if(n===clearTimeout)return clearTimeout(e);if((n===a||!n)&&clearTimeout)return n=clearTimeout,clearTimeout(e);try{n(e)}catch(t){try{return n.call(null,e)}catch(t){return n.call(this,e)}}}(e)}}function p(e,t){this.fun=e,this.array=t}function m(){}i.nextTick=function(e){var t=Array(arguments.length-1);if(arguments.length>1)for(var n=1;n<arguments.length;n++)t[n-1]=arguments[n];l.push(new p(e,t)),1!==l.length||c||r(h)},p.prototype.run=function(){this.fun.apply(null,this.array)},i.title="browser",i.browser=!0,i.env={},i.argv=[],i.version="",i.versions={},i.on=m,i.addListener=m,i.once=m,i.off=m,i.removeListener=m,i.removeAllListeners=m,i.emit=m,i.prependListener=m,i.prependOnceListener=m,i.listeners=function(e){return[]},i.binding=function(e){throw Error("process.binding is not supported")},i.cwd=function(){return"/"},i.chdir=function(e){throw Error("process.chdir is not supported")},i.umask=function(){return 0}}},n={};function o(e){var i=n[e];if(void 0!==i)return i.exports;var s=n[e]={exports:{}},a=!0;try{t[e](s,s.exports,o),a=!1}finally{a&&delete n[e]}return s.exports}o.ab="//";var i=o(229);e.exports=i}()},9476:function(e,t,n){"use strict";let o,i;function s(e){return null!=e&&"object"==typeof e&&!Array.isArray(e)}async function a(e){try{let t=await e.json();if(!s(t))return e.statusText||"Unknown error";let n=t.detail,o=s(n)?n.message:n;if("string"==typeof o)return o}catch(e){console.warn("Failed to parse API error response as JSON:",e)}return e.statusText||"Unknown error"}n.d(t,{hc:function(){return e_},sX:function(){return eb}});class r extends Error{closeCode;closeReason;constructor(e,t){super(e),this.name="SessionConnectionError",this.closeCode=t?.closeCode,this.closeReason=t?.closeReason}}async function l({conversationId:e,origin:t,file:n,filename:o}){let i=(t??"https://api.elevenlabs.io").replace(/^wss:\/\//,"https://").replace(/^ws:\/\//,"http://"),r=o??("name"in n&&"string"==typeof n.name?n.name:`upload.${(n.type||"image/png").split("/").pop()?.split("+")[0]}`),l=new FormData;l.append("file",n,r);let c=await fetch(`${i}/v1/convai/conversations/${e}/files`,{method:"POST",body:l});if(!c.ok){let e=await a(c);throw Error(`Upload failed: ${c.status} ${e}`)}let u=await c.json();!function(e,t="Expected a JSON object"){if(!s(e))throw Error(t)}(u,"Upload response is not a JSON object");let{file_id:d}=u;if("string"!=typeof d||!d)throw Error("Upload response is missing a valid file_id");return{fileId:d}}let c=["onConnect","onDisconnect","onError","onMessage","onAudio","onModeChange","onStatusChange","onCanSendFeedbackChange","onUnhandledClientToolCall","onVadScore","onMCPToolCall","onMCPConnectionStatus","onAgentToolRequest","onAgentToolResponse","onConversationMetadata","onAsrInitiationMetadata","onInterruption","onAgentResponseCorrection","onAgentChatResponsePart","onAudioAlignment","onGuardrailTriggered","onAgentTyping","onExternalAgentConnected","onPing","onDebug"],u={reason:"agent",context:{type:"end_call",reason:"Agent ended the call"}};function d(e){let{textOnly:t}=e.overrides?.conversation??{},{textOnly:n}=e;return"boolean"==typeof n?("boolean"==typeof t&&n!==t&&console.warn(`Conflicting textOnly options provided: ${n} via options.textOnly (will be used) and ${t} via options.overrides.conversation.textOnly (will be ignored)`),n):"boolean"==typeof t?t:void 0}class h{options;connection;lastInterruptTimestamp=0;mode="listening";status="connecting";volume=1;currentEventId=1;canSendFeedback=!1;static getFullOptions(e){let t=d(e);return{clientTools:{},onConnect:()=>{},onDebug:()=>{},onDisconnect:()=>{},onError:()=>{},onMessage:()=>{},onAudio:()=>{},onModeChange:()=>{},onStatusChange:()=>{},onCanSendFeedbackChange:()=>{},onInterruption:()=>{},onAgentResponseCorrection:()=>{},onAgentTyping:()=>{},onExternalAgentConnected:()=>{},onPing:()=>{},...e,textOnly:t,overrides:{...e.overrides,conversation:{...e.overrides?.conversation,textOnly:t}}}}constructor(e,t){this.options=e,this.connection=t,this.connection.onMessage(this.onMessage),this.connection.onDisconnect(this.endSessionWithDetails),this.connection.onModeChange(e=>this.updateMode(e))}markConnected(){this.updateStatus("connected")}endSession(){return this.endSessionWithDetails({reason:"user"})}endSessionWithDetails=async e=>{("connected"===this.status||"connecting"===this.status)&&(this.updateStatus("disconnecting"),await this.handleEndSession(),this.updateStatus("disconnected"),this.options.onDisconnect&&this.options.onDisconnect(e))};async handleEndSession(){this.connection.close()}updateMode(e){e!==this.mode&&(this.mode=e,this.options.onModeChange&&this.options.onModeChange({mode:e}))}updateStatus(e){e!==this.status&&(this.status=e,this.options.onStatusChange&&this.options.onStatusChange({status:e}),this.updateCanSendFeedback())}updateCanSendFeedback(){let e="connected"===this.status;this.canSendFeedback!==e&&(this.canSendFeedback=e,this.options.onCanSendFeedbackChange&&this.options.onCanSendFeedbackChange({canSendFeedback:e}))}handleInterruption(e){e.interruption_event&&(this.lastInterruptTimestamp=e.interruption_event.event_id,this.options.onInterruption&&this.options.onInterruption({event_id:e.interruption_event.event_id}))}handleAgentResponse(e){this.currentEventId=e.agent_response_event.event_id,this.options.onMessage&&this.options.onMessage({source:"ai",role:"agent",message:e.agent_response_event.agent_response,event_id:e.agent_response_event.event_id})}handleAgentResponseCorrection(e){this.options.onAgentResponseCorrection&&this.options.onAgentResponseCorrection(e.agent_response_correction_event)}handleUserTranscript(e){this.options.onMessage&&this.options.onMessage({source:"user",role:"user",message:e.user_transcription_event.user_transcript,event_id:e.user_transcription_event.event_id})}handleTentativeAgentResponse(e){this.options.onDebug&&this.options.onDebug({type:"tentative_agent_response",response:e.tentative_agent_response_internal_event.tentative_agent_response})}handleVadScore(e){this.options.onVadScore&&this.options.onVadScore({vadScore:e.vad_score_event.vad_score})}handlePing(e){this.options.onPing&&this.options.onPing(e.ping_event)}async handleClientToolCall(e){if(Object.prototype.hasOwnProperty.call(this.options.clientTools,e.client_tool_call.tool_name))try{let t=await this.options.clientTools[e.client_tool_call.tool_name](e.client_tool_call.parameters)??"Client tool execution successful.",n="object"==typeof t?JSON.stringify(t):String(t);this.connection.sendMessage({type:"client_tool_result",tool_call_id:e.client_tool_call.tool_call_id,result:n,is_error:!1})}catch(t){this.onError(`Client tool execution failed with following error: ${t?.message}`,{clientToolName:e.client_tool_call.tool_name}),this.connection.sendMessage({type:"client_tool_result",tool_call_id:e.client_tool_call.tool_call_id,result:`Client tool execution failed: ${t?.message}`,is_error:!0})}else{if(this.options.onUnhandledClientToolCall){this.options.onUnhandledClientToolCall(e.client_tool_call);return}this.onError(`Client tool with name ${e.client_tool_call.tool_name} is not defined on client`,{clientToolName:e.client_tool_call.tool_name}),this.connection.sendMessage({type:"client_tool_result",tool_call_id:e.client_tool_call.tool_call_id,result:`Client tool with name ${e.client_tool_call.tool_name} is not defined on client`,is_error:!0})}}handleAudio(e){}handleMCPToolCall(e){this.options.onMCPToolCall&&this.options.onMCPToolCall(e.mcp_tool_call)}handleMCPConnectionStatus(e){this.options.onMCPConnectionStatus&&this.options.onMCPConnectionStatus(e.mcp_connection_status)}handleAgentToolRequest(e){this.options.onAgentToolRequest&&this.options.onAgentToolRequest(e.agent_tool_request)}handleAgentToolResponse(e){"end_call"===e.agent_tool_response.tool_name&&this.endSessionWithDetails(u).catch(e=>{this.onError("Failed to end session after agent end_call",e)}),this.options.onAgentToolResponse?.(e.agent_tool_response)}handleAgentToolResponseFullPayload(e){"end_call"===e.agent_tool_response_full_payload.tool_name&&this.endSessionWithDetails(u).catch(e=>{this.onError("Failed to end session after agent end_call",e)}),this.options.onAgentToolResponse?.(e.agent_tool_response_full_payload)}handleConversationMetadata(e){this.options.onConversationMetadata&&this.options.onConversationMetadata(e.conversation_initiation_metadata_event)}handleAsrInitiationMetadata(e){this.options.onAsrInitiationMetadata&&this.options.onAsrInitiationMetadata(e.asr_initiation_metadata_event)}handleAgentChatResponsePart(e){this.options.onAgentChatResponsePart&&this.options.onAgentChatResponsePart(e.text_response_part)}handleGuardrailTriggered(e){this.options.onGuardrailTriggered&&this.options.onGuardrailTriggered()}handleAgentTyping(e){this.options.onAgentTyping&&this.options.onAgentTyping(e.agent_typing_event)}handleExternalAgentConnected(e){this.options.onExternalAgentConnected&&this.options.onExternalAgentConnected()}handleErrorEvent(e){let t=e.error_event,n=t?.error_type,o=t?.message||t?.reason||"Unknown error";if("max_duration_exceeded"===n){this.endSessionWithDetails({reason:"error",message:o,context:{type:"max_duration_exceeded"}}).catch(e=>{this.onError("Failed to end session after max_duration_exceeded",e)});return}this.onError(`Server error: ${o}`,{errorType:n,code:t?.code,debugMessage:t?.debug_message,details:t?.details})}onMessage=async e=>{switch(e.type){case"interruption":this.handleInterruption(e);return;case"agent_response":this.handleAgentResponse(e);return;case"agent_response_correction":this.handleAgentResponseCorrection(e);return;case"user_transcript":this.handleUserTranscript(e);return;case"internal_tentative_agent_response":this.handleTentativeAgentResponse(e);return;case"client_tool_call":try{await this.handleClientToolCall(e)}catch(t){this.onError(`Unexpected error in client tool call handling: ${t instanceof Error?t.message:String(t)}`,{clientToolName:e.client_tool_call.tool_name,toolCallId:e.client_tool_call.tool_call_id})}return;case"audio":this.handleAudio(e);return;case"vad_score":this.handleVadScore(e);return;case"ping":this.connection.sendMessage({type:"pong",event_id:e.ping_event.event_id}),this.handlePing(e);return;case"mcp_tool_call":this.handleMCPToolCall(e);return;case"mcp_connection_status":this.handleMCPConnectionStatus(e);return;case"agent_tool_request":this.handleAgentToolRequest(e);return;case"agent_tool_response":this.handleAgentToolResponse(e);return;case"agent_tool_response_full_payload":this.handleAgentToolResponseFullPayload(e);return;case"conversation_initiation_metadata":this.handleConversationMetadata(e);return;case"asr_initiation_metadata":this.handleAsrInitiationMetadata(e);return;case"agent_chat_response_part":this.handleAgentChatResponsePart(e);return;case"guardrail_triggered":this.handleGuardrailTriggered(e);return;case"error":this.handleErrorEvent(e);return;case"agent_typing":this.handleAgentTyping(e);return;case"external_agent_connected":this.handleExternalAgentConnected(e);return;default:this.options.onDebug&&this.options.onDebug(e);return}};onError(e,t){console.error(e,t),this.options.onError&&this.options.onError(e,t)}getId(){return this.connection.conversationId}isOpen(){return"connected"===this.status}sendFeedback(e,t){if(!this.canSendFeedback){console.warn("Cannot send feedback: the conversation is not connected.");return}this.connection.sendMessage({type:"feedback",score:null!==e?e?"like":"dislike":null,event_id:t??this.currentEventId})}sendContextualUpdate(e,t){this.connection.sendMessage({type:"contextual_update",text:e,...t?.contextId?{context_id:t.contextId}:{}})}sendUserMessage(e){this.connection.sendMessage({type:"user_message",text:e})}sendUserActivity(){this.connection.sendMessage({type:"user_activity"})}sendMCPToolApprovalResult(e,t){this.connection.sendMessage({type:"mcp_tool_approval_result",tool_call_id:e,is_approved:t})}sendMultimodalMessage(e){this.connection.sendMessage({type:"multimodal_message",text:e.text?{type:"user_message",text:e.text}:void 0,file:e.fileId?{type:"file_input",file_id:e.fileId}:void 0})}async uploadFile(e){return l({conversationId:this.connection.conversationId,origin:this.options.origin,file:e})}}let p=Object.freeze({name:"js_sdk",version:"1.15.1"});class m{queue=[];disconnectionDetails=null;onDisconnectCallback=null;onMessageCallback=null;onModeChangeCallback=null;onDebug;constructor(e={}){this.onDebug=e.onDebug}debug(e){this.onDebug&&this.onDebug(e)}onMessage(e){this.onMessageCallback=e;let t=this.queue;this.queue=[],t.length>0&&queueMicrotask(()=>{t.forEach(e)})}onDisconnect(e){this.onDisconnectCallback=e;let t=this.disconnectionDetails;t&&queueMicrotask(()=>{e(t)})}onModeChange(e){this.onModeChangeCallback=e}updateMode(e){this.onModeChangeCallback?.(e)}disconnect(e){this.disconnectionDetails||(this.disconnectionDetails=e,this.onDisconnectCallback?.(e))}handleMessage(e){this.onMessageCallback?this.onMessageCallback(e):this.queue.push(e)}}function f(e){let[t,n]=e.split("_");if(!["pcm","ulaw"].includes(t))throw Error(`Invalid format: ${e}`);let o=Number.parseInt(n);if(Number.isNaN(o))throw Error(`Invalid sample rate: ${n}`);return{format:t,sampleRate:o}}var g,v,y,C,w,_,b=n(4284);let k="conversation_initiation_client_data";function S(e){let t={type:k};return e.overrides&&(t.conversation_config_override={agent:{prompt:e.overrides.agent?.prompt,first_message:e.overrides.agent?.firstMessage,language:e.overrides.agent?.language},tts:{voice_id:e.overrides.tts?.voiceId,speed:e.overrides.tts?.speed,stability:e.overrides.tts?.stability,similarity_boost:e.overrides.tts?.similarityBoost},...e.overrides.asr?.keywords!==void 0?{asr:{keywords:e.overrides.asr.keywords}}:{},conversation:{text_only:e.overrides.conversation?.textOnly}}),e.customLlmExtraBody&&(t.custom_llm_extra_body=e.customLlmExtraBody),e.dynamicVariables&&(t.dynamic_variables=e.dynamicVariables),e.userId&&(t.user_id=e.userId),t.source_info={source:p.name,version:p.version},e.toolMockConfig&&(t.tool_mock_config={mocking_strategy:e.toolMockConfig.mockingStrategy,mocked_tool_names:e.toolMockConfig.mockedToolNames,fallback_strategy:e.toolMockConfig.fallbackStrategy}),t}function A(e){return btoa(String.fromCharCode(...new Uint8Array(e)))}let E={getVolume:()=>0,getByteFrequencyData:()=>{}};function M(e,t,n){let o=e.length,i=n/2/o,s=Math.floor(100/i),a=Math.min(Math.ceil(8e3/i),o),r=a-s,l=t.length;for(let n=0;n<l;n++){let o=n/l*r,i=s+Math.floor(o),c=Math.min(i+1,a-1),u=o-Math.floor(o);t[n]=Math.round(e[i]*(1-u)+e[c]*u)}}class T extends m{conversationId;inputFormat;outputFormat;room;isConnected=!1;audioEventId=1;outputDeviceId=null;audioAdapter;inputAnalyser=void 0;inputVolumeProvider=E;outputAnalyser=void 0;outputVolumeProvider=E;_isMuted=!1;input={close:async()=>{if(this.isConnected)try{this.room.localParticipant.audioTrackPublications.forEach(e=>{e.track&&e.track.stop()})}catch(e){console.warn("Error stopping local tracks:",e)}},setDevice:async e=>{if(e?.sampleRate!==void 0||e?.format!==void 0||e?.preferHeadphonesForIosDevices!==void 0)throw Error("WebRTC input device does not support sampleRate, format, or preferHeadphonesForIosDevices options");let t=e?.inputDeviceId;t&&await this.setAudioInputDevice(t)},setMuted:async e=>{if(!this.isConnected||!this.room.localParticipant){console.warn("Cannot set microphone muted: room not connected or no local participant");return}this._isMuted=e;let t=this.room.localParticipant.getTrackPublication(b.fQ.Source.Microphone);if(t?.track)try{e?await t.track.mute():await t.track.unmute()}catch(t){await this.room.localParticipant.setMicrophoneEnabled(!e)}else await this.room.localParticipant.setMicrophoneEnabled(!e);if(!e){let e=this.room.localParticipant.getTrackPublication(b.fQ.Source.Microphone)?.track;e&&this.setupInputAnalyser(e.mediaStreamTrack)}},isMuted:()=>this._isMuted,getAnalyser:()=>this.inputAnalyser,getVolume:()=>this._isMuted?0:this.inputVolumeProvider.getVolume(),getByteFrequencyData:e=>{if(this._isMuted){e.fill(0);return}this.inputVolumeProvider.getByteFrequencyData(e)}};output={close:async()=>{},setDevice:async e=>{if(e?.sampleRate!==void 0||e?.format!==void 0)throw Error("WebRTC output device does not support sampleRate or format options");let t=e?.outputDeviceId;t&&await this.setAudioOutputDevice(t)},setVolume:e=>{this.setAudioVolume(e)},interrupt:e=>{},getAnalyser:()=>this.outputAnalyser,getVolume:()=>this.outputVolumeProvider.getVolume(),getByteFrequencyData:e=>{this.outputVolumeProvider.getByteFrequencyData(e)}};constructor(e,t,n,i,s={}){super(s),this.room=e,this.conversationId=t,this.inputFormat=n,this.outputFormat=i,this.audioAdapter=o?.()??null,this.setupRoomEventListeners()}static async create(e){let t;if("conversationToken"in e&&e.conversationToken)t=e.conversationToken;else if("agentId"in e&&e.agentId)try{let{name:n,version:o}=p,i=(e.origin??"https://api.elevenlabs.io").replace(/^wss:\/\//,"https://"),r=`${i}/v1/convai/conversation/token?agent_id=${e.agentId}&source=${n}&version=${o}`;e.environment&&(r+=`&environment=${encodeURIComponent(e.environment)}`);let l=await fetch(r);if(!l.ok){let e=await a(l);throw Error(`ElevenLabs API returned ${l.status} ${e}`)}let c=await l.json();if(!s(c)||"string"!=typeof c.token||!(t=c.token))throw Error("No conversation token received from API")}catch(n){let t=n instanceof Error?n.message:String(n);throw n instanceof Error&&n.message.includes("401")&&(t="Your agent has authentication enabled, but no signed URL or conversation token was provided."),Error(`Failed to fetch conversation token for agent ${e.agentId}: ${t}`)}else throw Error("Either conversationToken or agentId is required for WebRTC connection");let n=new b.du({singlePeerConnection:!1});try{let o=`room_${Date.now()}`,i=f("pcm_48000"),s=f("pcm_48000"),a=new T(n,o,i,s,e),r=e.livekitUrl||"wss://livekit.rtc.elevenlabs.io",l=e.textOnly?Promise.resolve():new Promise((e,t)=>{n.once(b.TQ.SignalConnected,()=>{n.localParticipant.setMicrophoneEnabled(!0).then(()=>e()).catch(t)})});await n.connect(r,t),await new Promise(e=>{if(a.isConnected)e();else{let t=()=>{n.off(b.TQ.Connected,t),e()};n.on(b.TQ.Connected,t)}}),await l;let c=n.localParticipant.getTrackPublication(b.fQ.Source.Microphone)?.track;c&&a.setupInputAnalyser(c.mediaStreamTrack),n.name&&(a.conversationId=n.name.match(/(conv_[a-zA-Z0-9]+)/)?.[0]||n.name);let u=S(e);return a.debug({type:k,message:u}),await a.sendMessage(u),a}catch(e){throw await n.disconnect(),e}}setupRoomEventListeners(){this.room.on(b.TQ.Connected,()=>{this.isConnected=!0}),this.room.on(b.TQ.Disconnected,e=>{this.isConnected=!1,this.disconnect({reason:"agent",context:{type:"close",reason:e?.toString()}})}),this.room.on(b.TQ.ConnectionStateChanged,e=>{e===b.em.Disconnected&&(this.isConnected=!1,this.disconnect({reason:"error",message:`LiveKit connection state changed to ${e}`,context:{type:"connection_state_changed"}}))}),this.room.on(b.TQ.DataReceived,(e,t)=>{try{let t=JSON.parse(new TextDecoder().decode(e));if("audio"===t.type)return;t.type?this.handleMessage(t):console.warn("Invalid socket event received:",t)}catch(t){console.warn("Failed to parse incoming data message:",t),console.warn("Raw payload:",new TextDecoder().decode(e))}}),this.room.on(b.TQ.TrackSubscribed,async(e,t,n)=>{e.kind===b.fQ.Kind.Audio&&n.identity.includes("agent")&&this.audioAdapter&&(await this.audioAdapter.attachRemoteTrack(e,this.outputDeviceId),await this.setupAudioCapture(e),this.onDebug?.({type:"audio_element_ready"}))}),this.room.on(b.TQ.ActiveSpeakersChanged,async e=>{e.length>0?this.updateMode(e[0].identity.startsWith("agent")?"speaking":"listening"):this.updateMode("listening")}),this.room.on(b.TQ.ParticipantDisconnected,e=>{e.identity?.startsWith("agent")&&this.disconnect({reason:"agent",context:{type:"close",reason:"agent disconnected"}})})}close(){if(this.isConnected){try{this.room.localParticipant.audioTrackPublications.forEach(e=>{e.track&&e.track.stop()})}catch(e){console.warn("Error stopping local tracks:",e)}this.audioAdapter?.cleanup(),this.inputAnalyser=void 0,this.outputAnalyser=void 0,this.inputVolumeProvider=E,this.outputVolumeProvider=E,this.room.disconnect()}}async sendMessage(e){if(!this.isConnected||!this.room.localParticipant){console.warn("Cannot send message: room not connected or no local participant");return}if(!("user_audio_chunk"in e))try{let t=new TextEncoder().encode(JSON.stringify(e));await this.room.localParticipant.publishData(t,{reliable:!0})}catch(t){this.debug({type:"send_message_error",message:{message:e,error:t}}),console.error("Failed to send message via WebRTC:",t)}}getRoom(){return this.room}setupInputAnalyser(e){if(this.audioAdapter)try{let t=this.audioAdapter.setupInputAnalysis(e);this.inputVolumeProvider=t.volumeProvider,this.inputAnalyser=t.analyser}catch(e){console.warn("[ConversationalAI] Failed to set up input volume analyser:",e)}}setInputVolumeProvider(e){this.inputVolumeProvider=e}setOutputVolumeProvider(e){this.outputVolumeProvider=e}async setupAudioCapture(e){if(this.audioAdapter)try{let t=await this.audioAdapter.setupOutputAnalysis(e,this.outputFormat,(e,t)=>{if(t>.01){let t=A(e),n=this.audioEventId++;this.handleMessage({type:"audio",audio_event:{audio_base_64:t,event_id:n}})}});this.outputVolumeProvider=t.volumeProvider,this.outputAnalyser=t.analyser}catch(e){console.warn("Failed to set up audio capture:",e)}}setAudioVolume(e){this.audioAdapter?.setVolume(e)}async setAudioOutputDevice(e){if(!this.audioAdapter)throw Error("Cannot set output device: no audio adapter available on this platform");await this.audioAdapter.setOutputDevice(e),this.outputDeviceId=e}async setAudioInputDevice(e){if(!this.isConnected||!this.room.localParticipant)throw Error("Cannot change input device: room not connected or no local participant");try{let t=this.room.localParticipant.getTrackPublication(b.fQ.Source.Microphone);t?.track&&(await t.track.stop(),await this.room.localParticipant.unpublishTrack(t.track));let n=await (0,b.s1)({deviceId:{exact:e},echoCancellation:!0,noiseSuppression:!0,autoGainControl:!0,channelCount:{ideal:1}});await this.room.localParticipant.publishTrack(n,{name:"microphone",source:b.fQ.Source.Microphone}),this.setupInputAnalyser(n.mediaStreamTrack)}catch(e){console.error("Failed to change input device:",e);try{await this.room.localParticipant.setMicrophoneEnabled(!0)}catch(e){console.error("Failed to recover microphone after device switch error:",e)}throw e}}}class I extends m{socket;conversationId;inputFormat;outputFormat;outputListeners=new Set;pendingAudioEvents=[];constructor(e,t,n,o){super(),this.socket=e,this.conversationId=t,this.inputFormat=n,this.outputFormat=o,this.socket.addEventListener("error",e=>{setTimeout(()=>this.disconnect({reason:"error",message:"The connection was closed due to a socket error.",context:{type:e.type}}),0)}),this.socket.addEventListener("close",e=>{let t=e.code,n=e.reason||void 0,o={type:e.type,code:t,reason:n};this.disconnect(1e3===t?{reason:"agent",context:o,closeCode:t,closeReason:n}:{reason:"error",message:n||"The connection was closed by the server.",context:o,closeCode:t,closeReason:n})}),this.socket.addEventListener("message",e=>{try{let t=JSON.parse(e.data);if(!t.type){this.debug({type:"invalid_event",message:"Received invalid socket event",data:e.data});return}this.handleMessage(t)}catch(t){this.debug({type:"parsing_error",message:"Failed to parse socket message",error:t instanceof Error?t.message:String(t),data:e.data})}})}static async create(e){let t=null;try{let n;let o=e.origin??"wss://api.elevenlabs.io",{name:i,version:s}=p;if(e.signedUrl){let t=e.signedUrl.includes("?")?"&":"?";n=`${e.signedUrl}${t}source=${i}&version=${s}`}else n=`${o}/v1/convai/conversation?agent_id=${e.agentId}&source=${i}&version=${s}`;e.environment&&(n+=`&environment=${encodeURIComponent(e.environment)}`);let a=["convai"];e.authorization&&a.push(`bearer.${e.authorization}`),t=new WebSocket(n,a);let{conversation_id:l,agent_output_audio_format:c,user_input_audio_format:u}=await new Promise((n,o)=>{t.addEventListener("open",()=>{let n=S(e);t?.send(JSON.stringify(n))},{once:!0}),t.addEventListener("error",e=>{setTimeout(()=>o(new r("The connection was closed due to a socket error.")),0)}),t.addEventListener("close",e=>{let t=e.reason||(1e3===e.code?"Connection closed normally before session could be established.":"Connection closed unexpectedly before session could be established.");o(new r(t,{closeCode:e.code,closeReason:e.reason||void 0}))}),t.addEventListener("message",e=>{let t=JSON.parse(e.data);t.type&&("conversation_initiation_metadata"===t.type?n(t.conversation_initiation_metadata_event):console.warn("First received message is not conversation metadata."))},{once:!0})}),d=f(u??"pcm_16000"),h=f(c);return new I(t,l,d,h)}catch(e){throw t?.close(),e}}close(){this.pendingAudioEvents=[],this.socket.close(1e3,"User ended conversation")}sendMessage(e){this.socket.send(JSON.stringify(e))}addListener(e){let t=this.outputListeners.size>0;if(this.outputListeners.add(e),t||0===this.pendingAudioEvents.length)return;let n=this.pendingAudioEvents;for(let t of(this.pendingAudioEvents=[],n))e(t)}removeListener(e){this.outputListeners.delete(e)}handleMessage(e){if(super.handleMessage(e),"audio"===e.type&&e.audio_event.audio_base_64){let t={audio_base_64:e.audio_event.audio_base_64};if(0===this.outputListeners.size){this.pendingAudioEvents.push(t);return}this.outputListeners.forEach(e=>e(t))}}}async function x(e){let t=function(e){let t="signedUrl"in e&&e.signedUrl;if(t&&"webrtc"===e.connectionType)throw Error("signedUrl only supports websocket connections. Remove connectionType or set it to 'websocket'.");return e.connectionType?e.connectionType:"conversationToken"in e&&e.conversationToken?"webrtc":t?"websocket":e.textOnly?"websocket":"webrtc"}(e);switch(t){case"websocket":return I.create(e);case"webrtc":return T.create(e);default:throw Error(`Unknown connection type: ${t}`)}}let P=new Map;function D(e,t){return async(n,o)=>{let i=P.get(e);if(i)return n.addModule(i);if(o)try{await n.addModule(o),P.set(e,o);return}catch(t){throw Error(`Failed to load the ${e} worklet module from path: ${o}. Error: ${t}`)}let s=new Blob([t],{type:"application/javascript"}),a=URL.createObjectURL(s);try{await n.addModule(a),P.set(e,a);return}catch{URL.revokeObjectURL(a)}try{let o=btoa(t),i=`data:application/javascript;base64,${o}`;await n.addModule(i),P.set(e,i)}catch(t){throw Error(`Failed to load the ${e} worklet module. Make sure the browser supports AudioWorklets. If you are using a strict CSP, you may need to self-host the worklet files.`)}}}let R=D("audioConcatProcessor",`/*
 * ulaw decoding logic taken from the wavefile library
 * https://github.com/rochars/wavefile/blob/master/lib/codecs/mulaw.js
 * USED BY @elevenlabs/client
 */

const decodeTable = [0, 132, 396, 924, 1980, 4092, 8316, 16764];

function decodeSample(muLawSample) {
  let sign;
  let exponent;
  let mantissa;
  let sample;
  muLawSample = ~muLawSample;
  sign = muLawSample & 0x80;
  exponent = (muLawSample >> 4) & 0x07;
  mantissa = muLawSample & 0x0f;
  sample = decodeTable[exponent] + (mantissa << (exponent + 3));
  if (sign !== 0) sample = -sample;

  return sample;
}

class AudioConcatProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buffers = []; // Initialize an empty buffer
    this.cursor = 0;
    this.currentBuffer = null;
    this.wasInterrupted = false;
    this.finished = false;

    this.port.onmessage = ({ data }) => {
      switch (data.type) {
        case "setFormat":
          this.format = data.format;
          if (globalThis.LibSampleRate && sampleRate !== data.sampleRate) {
            globalThis.LibSampleRate.create(
              1,
              data.sampleRate,
              sampleRate
            ).then(resampler => {
              this.resampler = resampler;
            });
          }
          break;
        case "buffer":
          this.wasInterrupted = false;
          this.buffers.push(
            this.format === "ulaw"
              ? new Uint8Array(data.buffer)
              : new Int16Array(data.buffer)
          );
          break;
        case "interrupt":
          this.wasInterrupted = true;
          break;
        case "clearInterrupted":
          if (this.wasInterrupted) {
            this.wasInterrupted = false;
            this.buffers = [];
            this.currentBuffer = null;
          }
      }
    };
  }
  process(_, outputs) {
    let finished = false;
    const output = outputs[0][0];
    for (let i = 0; i < output.length; i++) {
      if (!this.currentBuffer) {
        if (this.buffers.length === 0) {
          finished = true;
          break;
        }
        this.currentBuffer = this.buffers.shift();
        if (this.resampler) {
          this.currentBuffer = this.resampler.full(this.currentBuffer);
        }
        this.cursor = 0;
      }

      let value = this.currentBuffer[this.cursor];
      if (this.format === "ulaw") {
        value = decodeSample(value);
      }
      output[i] = value / 32768;
      this.cursor++;

      if (this.cursor >= this.currentBuffer.length) {
        this.currentBuffer = null;
      }
    }

    if (this.finished !== finished) {
      this.finished = finished;
      this.port.postMessage({ type: "process", finished });
    }

    return true; // Continue processing
  }
}

registerProcessor("audioConcatProcessor", AudioConcatProcessor);
`);async function F(e,t){await e.audioWorklet.addModule(t||"https://cdn.jsdelivr.net/npm/@alexanderolsen/libsamplerate-js@2.1.2/dist/libsamplerate.worklet.js")}function L(e,t){let n,o;let i=e.frequencyBinCount;return{getVolume:()=>(n??=new Uint8Array(i),o??=new Uint8Array(i),e.getByteFrequencyData(n),M(n,o,t),function(e){if(0===e.length)return 0;let t=0;for(let n=0;n<e.length;n++)t+=e[n]/255;return(t/=e.length)<0?0:t>1?1:t}(o)),getByteFrequencyData(o){n??=new Uint8Array(i),e.getByteFrequencyData(n),M(n,o,t)}}}function U(){return["iPad Simulator","iPhone Simulator","iPod Simulator","iPad","iPhone","iPod"].includes(navigator.platform)||navigator.userAgent.includes("Mac")&&"ontouchend"in document}class O{context;analyser;gain;worklet;audioElement;static async create({sampleRate:e,format:t,outputDeviceId:n,workletPaths:o,libsampleratePath:i,audioContext:s}){let a=s??null,r=null;try{let s=navigator.mediaDevices.getSupportedConstraints().sampleRate;a||(a=new AudioContext(s?{sampleRate:e}:{}));let l=a.createAnalyser(),c=a.createGain();(r=new Audio).src="",r.load(),r.autoplay=!0,r.style.display="none",document.body.appendChild(r);let u=a.createMediaStreamDestination();r.srcObject=u.stream,c.connect(l),l.connect(u),s&&a.sampleRate===e||(a.sampleRate!==e&&console.warn(`[ConversationalAI] Sample rate ${e} not available, resampling to ${a.sampleRate}`),await F(a,i)),await R(a.audioWorklet,o?.audioConcatProcessor);let d=new AudioWorkletNode(a,"audioConcatProcessor");return d.port.postMessage({type:"setFormat",format:t,sampleRate:e}),d.connect(c),await a.resume(),!function({sampleRate:e,format:t,worklet:n,audioElement:o}){if(!U())return;let i=Math.floor(100*e/1e3),s="ulaw"===t?new Uint8Array(i).fill(255):new Int16Array(i);n.port.postMessage({type:"buffer",buffer:s.buffer}),o.play().catch(()=>{})}({sampleRate:e,format:t,worklet:d,audioElement:r}),n&&r.setSinkId&&await r.setSinkId(n),new O(a,l,c,d,r)}catch(e){throw r?.parentNode&&r.parentNode.removeChild(r),r?.pause(),a&&"closed"!==a.state&&await a.close(),e}}volume=1;interrupted=!1;interruptTimeout=null;volumeProvider;constructor(e,t,n,o,i){this.context=e,this.analyser=t,this.gain=n,this.worklet=o,this.audioElement=i,this.worklet.port.start(),this.volumeProvider=L(t,e.sampleRate)}getAnalyser(){return this.analyser}getVolume(){return this.volumeProvider.getVolume()}getByteFrequencyData(e){this.volumeProvider.getByteFrequencyData(e)}addListener(e){this.worklet.port.addEventListener("message",e)}removeListener(e){this.worklet.port.removeEventListener("message",e)}setVolume(e){this.volume=e,this.gain.gain.value=e}playAudio(e){this.gain.gain.cancelScheduledValues(this.context.currentTime),this.gain.gain.value=this.volume,this.interruptTimeout&&(clearTimeout(this.interruptTimeout),this.interruptTimeout=null),this.worklet.port.postMessage({type:"clearInterrupted"}),this.worklet.port.postMessage({type:"buffer",buffer:e})}interrupt(e=2e3){this.interrupted=!0,this.interruptTimeout&&(clearTimeout(this.interruptTimeout),this.interruptTimeout=null),this.worklet.port.postMessage({type:"interrupt"}),this.gain.gain.exponentialRampToValueAtTime(1e-4,this.context.currentTime+e/1e3),this.interruptTimeout=setTimeout(()=>{this.interrupted=!1,this.gain.gain.value=this.volume,this.worklet.port.postMessage({type:"clearInterrupted"}),this.interruptTimeout=null},e)}async setDevice(e){if(!("setSinkId"in HTMLAudioElement.prototype))throw Error("setSinkId is not supported in this browser");let t=e?.outputDeviceId;await this.audioElement.setSinkId(t||"")}async close(){this.interruptTimeout&&(clearTimeout(this.interruptTimeout),this.interruptTimeout=null),this.audioElement.parentNode&&this.audioElement.parentNode.removeChild(this.audioElement),this.audioElement.pause(),await this.context.close()}}let V=D("rawAudioProcessor",`/*
 * ulaw encoding logic taken from the wavefile library
 * https://github.com/rochars/wavefile/blob/master/lib/codecs/mulaw.js
 * USED BY @elevenlabs/client
 */

const BIAS = 0x84;
const CLIP = 32635;
const encodeTable = [
  0,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3,
  4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
  5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
  5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7
];

function encodeSample(sample) {
  let sign;
  let exponent;
  let mantissa;
  let muLawSample;
  sign = (sample >> 8) & 0x80;
  if (sign !== 0) sample = -sample;
  sample = sample + BIAS;
  if (sample > CLIP) sample = CLIP;
  exponent = encodeTable[(sample>>7) & 0xFF];
  mantissa = (sample >> (exponent+3)) & 0x0F;
  muLawSample = ~(sign | (exponent << 4) | mantissa);
  
  return muLawSample;
}

class RawAudioProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
              
    this.port.onmessage = ({ data }) => {
      switch (data.type) {
        case "setFormat":
          this.isMuted = false;
          this.buffer = []; // Initialize an empty buffer
          const chunkDurationMs = data.chunkDurationMs ?? 25;
          this.bufferSize = Math.max(
            1,
            Math.round((data.sampleRate * chunkDurationMs) / 1000)
          );
          this.format = data.format;

          if (globalThis.LibSampleRate && sampleRate !== data.sampleRate) {
            globalThis.LibSampleRate.create(1, sampleRate, data.sampleRate).then(resampler => {
              this.resampler = resampler;
            });
          }
          break;
        case "setMuted":
          this.isMuted = data.isMuted;
          break;
      }
    };
  }
  process(inputs) {
    if (!this.buffer) {
      return true;
    }
    
    const input = inputs[0]; // Get the first input node
    if (input.length > 0) {
      let channelData = input[0]; // Get the first channel's data

      // Resample the audio if necessary
      if (this.resampler) {
        channelData = this.resampler.full(channelData);
      }

      // Add channel data to the buffer
      this.buffer.push(...channelData);
      // Get max volume 
      let sum = 0.0;
      for (let i = 0; i < channelData.length; i++) {
        sum += channelData[i] * channelData[i];
      }
      const maxVolume = Math.sqrt(sum / channelData.length);
      // Check if buffer size has reached or exceeded the threshold
      if (this.buffer.length >= this.bufferSize) {
        const float32Array = this.isMuted 
          ? new Float32Array(this.buffer.length)
          : new Float32Array(this.buffer);

        let encodedArray = this.format === "ulaw"
          ? new Uint8Array(float32Array.length)
          : new Int16Array(float32Array.length);

        // Iterate through the Float32Array and convert each sample to PCM16
        for (let i = 0; i < float32Array.length; i++) {
          // Clamp the value to the range [-1, 1]
          let sample = Math.max(-1, Math.min(1, float32Array[i]));

          // Scale the sample to the range [-32768, 32767]
          let value = sample < 0 ? sample * 32768 : sample * 32767;
          if (this.format === "ulaw") {
            value = encodeSample(Math.round(value));
          }

          encodedArray[i] = value;
        }

        // Send the buffered data to the main script
        this.port.postMessage([encodedArray, maxVolume]);

        // Clear the buffer after sending
        this.buffer = [];
      }
    }
    return true; // Continue processing
  }
}
registerProcessor("rawAudioProcessor", RawAudioProcessor);
`),N={echoCancellation:!0,noiseSuppression:!0,autoGainControl:!0,channelCount:{ideal:1}};class ${context;analyser;worklet;inputStream;mediaStreamSource;permissions;onError;static async create({sampleRate:e,format:t,preferHeadphonesForIosDevices:n,inputDeviceId:o,workletPaths:i,libsampleratePath:s,onError:a,inputChunkDurationMs:r=25}){let l=null,c=null;try{let u={sampleRate:{ideal:e},...N};if(U()&&n){let e=(await window.navigator.mediaDevices.enumerateDevices()).find(e=>"audioinput"===e.kind&&["airpod","headphone","earphone"].find(t=>e.label.toLowerCase().includes(t)));e&&(u.deviceId={ideal:e.deviceId})}o&&(u.deviceId=$.getDeviceIdConstraint(o));let d=navigator.mediaDevices.getSupportedConstraints().sampleRate,h=(l=new window.AudioContext(d?{sampleRate:e}:{})).createAnalyser();d||await F(l,s),await V(l.audioWorklet,i?.rawAudioProcessor);let p={voiceIsolation:!0,...u};c=await navigator.mediaDevices.getUserMedia({audio:p});let m=l.createMediaStreamSource(c),f=new AudioWorkletNode(l,"rawAudioProcessor");f.port.postMessage({type:"setFormat",format:t,sampleRate:e,chunkDurationMs:r}),m.connect(h),h.connect(f),await l.resume();let g=await navigator.permissions.query({name:"microphone"});return new $(l,h,f,c,m,g,a)}catch(e){throw c?.getTracks().forEach(e=>{e.stop()}),l?.close(),e}}static getDeviceIdConstraint(e){if(e)return U()?{ideal:e}:{exact:e}}muted=!1;volumeProvider;constructor(e,t,n,o,i,s,a=console.error){this.context=e,this.analyser=t,this.worklet=n,this.inputStream=o,this.mediaStreamSource=i,this.permissions=s,this.onError=a,this.permissions.addEventListener("change",this.handlePermissionsChange),this.worklet.port.start(),this.volumeProvider=L(t,e.sampleRate)}getAnalyser(){return this.analyser}getVolume(){return this.muted?0:this.volumeProvider.getVolume()}getByteFrequencyData(e){if(this.muted){e.fill(0);return}this.volumeProvider.getByteFrequencyData(e)}isMuted(){return this.muted}addListener(e){this.worklet.port.addEventListener("message",e)}removeListener(e){this.worklet.port.removeEventListener("message",e)}forgetInputStreamAndSource(){for(let e of this.inputStream.getTracks())e.stop();this.mediaStreamSource.disconnect()}async close(){this.forgetInputStreamAndSource(),this.permissions.removeEventListener("change",this.handlePermissionsChange),await this.context.close()}async setMuted(e){this.muted=e,this.worklet.port.postMessage({type:"setMuted",isMuted:e})}settingInput=!1;async setDevice(e){try{if(this.settingInput)throw Error("Input device is already being set");this.settingInput=!0;let t=e?.inputDeviceId,n={...N};t&&(n.deviceId=$.getDeviceIdConstraint(t));let o={voiceIsolation:!0,...n},i=await navigator.mediaDevices.getUserMedia({audio:o});this.forgetInputStreamAndSource(),this.inputStream=i,this.mediaStreamSource=this.context.createMediaStreamSource(i),this.mediaStreamSource.connect(this.analyser)}catch(e){throw this.onError("Failed to switch input device:",e),e}finally{this.settingInput=!1}}handlePermissionsChange=()=>{if("denied"===this.permissions.state)this.onError("Microphone permission denied");else if(!this.settingInput){let[e]=this.inputStream.getAudioTracks(),{deviceId:t}=e?.getSettings()??{};this.setDevice({inputDeviceId:t}).catch(e=>{this.onError("Failed to reset input device after permission change:",e)})}}}let q={default:0,android:3e3};function B(e,t="default"){let n=e??q;return"android"===t?n.android??n.default:"ios"===t?n.ios??n.default:n.default}async function j(e){e>0&&await new Promise(t=>setTimeout(t,e))}let W=["touchstart","touchend","click"],Q=null,z=null,G=!1;function H(){z&&(clearTimeout(z),z=null)}function J(){Q&&(Q.close().catch(()=>{}),Q=null,H())}async function Y(){if("wakeLock"in navigator)try{return await navigator.wakeLock.request("screen")}catch(e){}return null}async function X(e,t,n){let[o,i]=await Promise.all([$.create({...t.inputFormat,preferHeadphonesForIosDevices:e.preferHeadphonesForIosDevices,inputDeviceId:e.inputDeviceId,inputChunkDurationMs:e.inputChunkDurationMs,workletPaths:e.workletPaths,libsampleratePath:e.libsampleratePath}),O.create({...t.outputFormat,outputDeviceId:e.outputDeviceId,workletPaths:e.workletPaths,audioContext:n??void 0})]),s=function(e,t){let n=e=>{let n=e.data[0];t.sendMessage({user_audio_chunk:A(n.buffer)})};return e.addListener(n),()=>{e.removeListener(n)}}(o,t),a=function(e,t){let n=e=>{t.playAudio(function(e){let t=atob(e),n=t.length,o=new Uint8Array(n);for(let e=0;e<n;e++)o[e]=t.charCodeAt(e);return o.buffer}(e.audio_base_64))};return e.addListener(n),()=>{e.removeListener(n)}}(t,i);return{input:o,output:i,playbackEventTarget:i,detach:async()=>{s(),a()}}}i=async function(e){let t=e.useWakeLock??!0,n=null,o=null,i=null;try{let s;t&&(n=await Y()),o=await navigator.mediaDevices.getUserMedia({audio:!0});let a=/android/i.test(navigator.userAgent)?"android":U()?"ios":"default";await j(B(e.connectionDelay,a));let r=await x(e);try{r instanceof I?(i=function(){let e=Q;return Q=null,H(),e}(),s={connection:r,...await X(e,r,i)},i=null):(J(),s=function(e){if(!(e instanceof T))throw Error(`setupWebRTCSession requires a WebRTCConnection. Received: ${e?.constructor?.name??typeof e}`);return{connection:e,input:e.input,output:e.output,playbackEventTarget:null,detach:async()=>{}}}(r))}catch(e){throw await i?.close().catch(()=>{}),i=null,r.close(),e}if(o){for(let e of o.getTracks())e.stop();o=null}let l=null;n&&(l=()=>{"visible"===document.visibilityState&&n?.released&&Y().then(e=>{n=e})},document.addEventListener("visibilitychange",l));let c=s.detach;return{...s,detach:async()=>{await c(),l&&document.removeEventListener("visibilitychange",l);try{await n?.release(),n=null}catch(e){}}}}catch(e){if(o)for(let e of o.getTracks())e.stop();try{await n?.release(),n=null}catch(e){}throw J(),e}};class K{audioElements=[];inputAudioContext=null;audioCaptureContext=null;async attachRemoteTrack(e,t){let n=e.attach();if(n.autoplay=!0,n.controls=!1,t&&n.setSinkId)try{await n.setSinkId(t)}catch(e){console.warn("Failed to set output device for new audio element:",e)}n.style.display="none",document.body.appendChild(n),this.audioElements.push(n)}setupInputAnalysis(e){this.inputAudioContext&&(this.inputAudioContext.close().catch(()=>{}),this.inputAudioContext=null);let t=new AudioContext,n=t.createAnalyser();return t.createMediaStreamSource(new MediaStream([e])).connect(n),this.inputAudioContext=t,{volumeProvider:L(n,t.sampleRate),analyser:n}}async setupOutputAnalysis(e,t,n){this.audioCaptureContext&&(this.audioCaptureContext.close().catch(()=>{}),this.audioCaptureContext=null);let o=new AudioContext;this.audioCaptureContext=o;let i=o.createAnalyser();i.fftSize=2048,i.smoothingTimeConstant=.8;let s=new MediaStream([e.mediaStreamTrack]),a=o.createMediaStreamSource(s),r=L(i,o.sampleRate);await V(o.audioWorklet);let l=new AudioWorkletNode(o,"rawAudioProcessor");return l.port.postMessage({type:"setFormat",format:t.format,sampleRate:t.sampleRate}),l.port.onmessage=e=>{let[t,o]=e.data;n(t.buffer,o)},a.connect(i),i.connect(l),{volumeProvider:r,analyser:i}}setVolume(e){for(let t of this.audioElements)t.volume=e}async setOutputDevice(e){if(!("setSinkId"in HTMLAudioElement.prototype))throw Error("setSinkId is not supported in this browser");await Promise.all(this.audioElements.map(async t=>{try{await t.setSinkId(e)}catch(e){throw console.error("Failed to set sink ID for audio element:",e),e}}))}cleanup(){for(let e of(this.inputAudioContext&&(this.inputAudioContext.close().catch(e=>{console.warn("Error closing input audio context:",e)}),this.inputAudioContext=null),this.audioCaptureContext&&(this.audioCaptureContext.close().catch(e=>{console.warn("Error closing audio capture context:",e)}),this.audioCaptureContext=null),this.audioElements))e.remove();this.audioElements=[]}}D("scribeAudioProcessor",`/*
 * Scribe Audio Processor for converting microphone audio to PCM16 format
 * Supports resampling for browsers like Firefox that don't support
 * AudioContext sample rate constraints.
 * USED BY @elevenlabs/client
 */

class ScribeAudioProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buffer = [];
    this.bufferSize = 4096; // Buffer size for optimal chunk transmission

    // Resampling state
    this.inputSampleRate = null;
    this.outputSampleRate = null;
    this.resampleRatio = 1;
    this.lastSample = 0;
    this.resampleAccumulator = 0;

    this.port.onmessage = ({ data }) => {
      if (data.type === "configure") {
        this.inputSampleRate = data.inputSampleRate;
        this.outputSampleRate = data.outputSampleRate;
        if (this.inputSampleRate && this.outputSampleRate) {
          this.resampleRatio = this.inputSampleRate / this.outputSampleRate;
        }
      }
    };
  }

  // Linear interpolation resampling
  resample(inputData) {
    if (this.resampleRatio === 1 || !this.inputSampleRate) {
      return inputData;
    }

    const outputSamples = [];

    for (let i = 0; i < inputData.length; i++) {
      const currentSample = inputData[i];

      // Generate output samples using linear interpolation
      while (this.resampleAccumulator < 1) {
        const interpolated =
          this.lastSample +
          (currentSample - this.lastSample) * this.resampleAccumulator;
        outputSamples.push(interpolated);
        this.resampleAccumulator += this.resampleRatio;
      }

      this.resampleAccumulator -= 1;
      this.lastSample = currentSample;
    }

    return new Float32Array(outputSamples);
  }

  process(inputs) {
    const input = inputs[0];
    if (input.length > 0) {
      let channelData = input[0]; // Get first channel (mono)

      // Resample if needed (for Firefox and other browsers that don't
      // support AudioContext sample rate constraints)
      if (this.resampleRatio !== 1) {
        channelData = this.resample(channelData);
      }

      // Add incoming audio to buffer
      for (let i = 0; i < channelData.length; i++) {
        this.buffer.push(channelData[i]);
      }

      // When buffer reaches threshold, convert and send
      if (this.buffer.length >= this.bufferSize) {
        const float32Array = new Float32Array(this.buffer);
        const int16Array = new Int16Array(float32Array.length);

        // Convert Float32 [-1, 1] to Int16 [-32768, 32767]
        for (let i = 0; i < float32Array.length; i++) {
          // Clamp the value to prevent overflow
          const sample = Math.max(-1, Math.min(1, float32Array[i]));
          // Scale to PCM16 range
          int16Array[i] = sample < 0 ? sample * 32768 : sample * 32767;
        }

        // Send to main thread as transferable ArrayBuffer
        this.port.postMessage(
          {
            audioData: int16Array.buffer
          },
          [int16Array.buffer]
        );

        // Clear buffer
        this.buffer = [];
      }
    }

    return true; // Continue processing
  }
}

registerProcessor("scribeAudioProcessor", ScribeAudioProcessor);

`);let Z=new Uint8Array(0);class ee extends h{type="text";setVolume(){throw Error("setVolume is not supported in text conversations")}setMicMuted(){throw Error("setMicMuted is not supported in text conversations")}getInputByteFrequencyData(){return Z}getOutputByteFrequencyData(){return Z}getInputVolume(){return 0}getOutputVolume(){return 0}static async startSession(e){let t=h.getFullOptions(e);t.onStatusChange&&t.onStatusChange({status:"connecting"}),t.onCanSendFeedbackChange&&t.onCanSendFeedbackChange({canSendFeedback:!1}),t.onModeChange&&t.onModeChange({mode:"listening"}),t.onCanSendFeedbackChange&&t.onCanSendFeedbackChange({canSendFeedback:!1});let n=null,o=null;try{return await j(B(t.connectionDelay)),n=await x(t),o=new ee(t,n),t.onConversationCreated?.(o),o.markConnected(),t.onConnect?.({conversationId:n.conversationId}),o}catch(e){throw o?await o.endSession().catch(()=>{}):(t.onStatusChange?.({status:"disconnected"}),n?.close()),e}}}class et extends h{input;output;playbackEventTarget;cleanUp;type="voice";static async startSession(e){let t=h.getFullOptions(e);t.onStatusChange&&t.onStatusChange({status:"connecting"}),t.onCanSendFeedbackChange&&t.onCanSendFeedbackChange({canSendFeedback:!1});let n=null,o=null;try{if(!i)throw Error('No voice session setup strategy registered. Import the platform-specific entry point (e.g. @elevenlabs/client via the "browser" export).');return o=await i(t),n=new et(t,o.connection,o.input,o.output,o.playbackEventTarget,o.detach),t.onConversationCreated?.(n),n.markConnected(),t.onConnect?.({conversationId:o.connection.conversationId}),n}catch(e){throw n?await n.endSession().catch(()=>{}):(o&&await o.detach().catch(()=>{}),t.onStatusChange?.({status:"disconnected"})),e}}inputFrequencyData;outputFrequencyData;handlePlaybackEvent=e=>{"process"===e.data.type&&this.updateMode(e.data.finished?"listening":"speaking")};constructor(e,t,n,o,i,s){super(e,t),this.input=n,this.output=o,this.playbackEventTarget=i,this.cleanUp=s,i?.addListener(this.handlePlaybackEvent)}async handleEndSession(){this.playbackEventTarget?.removeListener(this.handlePlaybackEvent),this.playbackEventTarget=null,await this.cleanUp(),await super.handleEndSession(),await this.input.close(),await this.output.close()}handleInterruption(e){super.handleInterruption(e),this.updateMode("listening"),this.output.interrupt()}handleAudio(e){super.handleAudio(e),e.audio_event.alignment&&this.options.onAudioAlignment&&this.options.onAudioAlignment(e.audio_event.alignment),this.lastInterruptTimestamp<=e.audio_event.event_id&&(e.audio_event.audio_base_64&&this.options.onAudio?.(e.audio_event.audio_base_64),this.currentEventId=e.audio_event.event_id,this.updateCanSendFeedback(),this.updateMode("speaking"))}static FREQUENCY_BIN_COUNT=1024;setMicMuted(e){this.input.setMuted(e).catch(e=>{this.options.onError?.("Failed to set input muted state",e)})}getInputByteFrequencyData(){return this.inputFrequencyData??=new Uint8Array(et.FREQUENCY_BIN_COUNT),this.input.getByteFrequencyData(this.inputFrequencyData),this.inputFrequencyData}getOutputByteFrequencyData(){return this.outputFrequencyData??=new Uint8Array(et.FREQUENCY_BIN_COUNT),this.output.getByteFrequencyData(this.outputFrequencyData),this.outputFrequencyData}getInputVolume(){return this.input.getVolume()}getOutputVolume(){return this.output.getVolume()}async changeInputDevice({sampleRate:e,format:t,preferHeadphonesForIosDevices:n,inputDeviceId:o}){try{await this.input.setDevice({inputDeviceId:o,sampleRate:e,format:t,preferHeadphonesForIosDevices:n})}catch(e){throw console.error("Error changing input device",e),e}}async changeOutputDevice({sampleRate:e,format:t,outputDeviceId:n}){try{await this.output.setDevice({outputDeviceId:n,sampleRate:e,format:t})}catch(e){throw console.error("Error changing output device",e),e}}setVolume=({volume:e})=>{let t=Number.isFinite(e)?Math.min(1,Math.max(0,e)):1;this.volume=t,this.output.setVolume(t)}}(g=C||(C={})).SESSION_STARTED="session_started",g.PARTIAL_TRANSCRIPT="partial_transcript",g.COMMITTED_TRANSCRIPT="committed_transcript",g.COMMITTED_TRANSCRIPT_WITH_TIMESTAMPS="committed_transcript_with_timestamps",g.AUTH_ERROR="auth_error",g.ERROR="error",g.OPEN="open",g.CLOSE="close",g.QUOTA_EXCEEDED="quota_exceeded",g.COMMIT_THROTTLED="commit_throttled",g.TRANSCRIBER_ERROR="transcriber_error",g.UNACCEPTED_TERMS="unaccepted_terms",g.RATE_LIMITED="rate_limited",g.INPUT_ERROR="input_error",g.QUEUE_OVERFLOW="queue_overflow",g.RESOURCE_EXHAUSTED="resource_exhausted",g.SESSION_TIME_LIMIT_EXCEEDED="session_time_limit_exceeded",g.CHUNK_SIZE_EXCEEDED="chunk_size_exceeded",g.INSUFFICIENT_AUDIO_ACTIVITY="insufficient_audio_activity",(v=w||(w={})).PCM_8000="pcm_8000",v.PCM_16000="pcm_16000",v.PCM_22050="pcm_22050",v.PCM_24000="pcm_24000",v.PCM_44100="pcm_44100",v.PCM_48000="pcm_48000",v.ULAW_8000="ulaw_8000",(y=_||(_={})).MANUAL="manual",y.VAD="vad";let en={startSession:async e=>(!function(){for(let e of["fetch","WebSocket","TextEncoder","TextDecoder","URL","btoa","atob"])if(void 0===globalThis[e])throw Error(`${e} is not available in this environment.`)}(),d(e)?ee.startSession(e):et.startSession(e))};!function(){if(!U()||G||"undefined"==typeof document)return;G=!0;let e=()=>{!function(){if(!U()||Q)return;let e=new AudioContext;(function(e){let t=e.createBuffer(1,1,22050),n=e.createBufferSource();n.buffer=t,n.connect(e.destination),n.start(0),e.resume().catch(()=>{})})(e),Q=e,z&&clearTimeout(z),z=setTimeout(()=>{z=null,J()},3e4)}()};for(let t of W)document.addEventListener(t,e,!0)}(),o=()=>new K;var eo=n(7993),ei=n(1514);let es=(0,eo.createContext)(null);function ea(){let e=(0,eo.useContext)(es);return e?.conversation??null}function er(){let e=(0,eo.useContext)(es);if(!e)throw Error("useRawConversationRef must be used within a ConversationProvider");return e.conversationRef}function el(e){let t=(0,eo.useContext)(es);if(!t)throw Error("useRegisterCallbacks must be used within a ConversationProvider");let{registerCallbacks:n}=t,o=(0,eo.useRef)(e),i=Object.keys(e).filter(t=>void 0!==e[t]).sort().join("|");(0,eo.useLayoutEffect)(()=>{o.current=e}),(0,eo.useLayoutEffect)(()=>n(Object.fromEntries((""===i?[]:i.split("|")).map(e=>[e,(...t)=>{let n=o.current[e];"function"==typeof n&&n(...t)}]))),[n,i])}let ec=new Uint8Array(0),eu=(0,eo.createContext)(null),ed=(0,eo.createContext)(null),eh=(0,eo.createContext)(null);function ep({children:e,isMuted:t,onMutedChange:n}){let o=ea(),i=er(),s="boolean"==typeof t,[a,r]=(0,eo.useState)(!1),l=s?t:a;el({onDisconnect(){s||r(!1)}}),(0,eo.useEffect)(()=>{s&&o&&o.setMicMuted(t)},[o,t,s]);let c=(0,eo.useCallback)(e=>{let t=i.current;if(!t)throw Error("No active conversation. Call startSession() first.");s||(t.setMicMuted(e),r(e)),n?.(e)},[i,s,n]),u=(0,eo.useMemo)(()=>({isMuted:l,setMuted:c}),[l,c]);return(0,ei.jsx)(eh.Provider,{value:u,children:e})}let em=(0,eo.createContext)(null),ef=(0,eo.createContext)(null),eg=(0,eo.createContext)(null);class ev{listeners=new Set;add(e){return this.listeners.add(e),()=>{this.listeners.delete(e)}}invoke(...e){for(let t of this.listeners)t(...e)}get size(){return this.listeners.size}}class ey{sets=new Map;constructor(e){for(let t of e)this.sets.set(t,new ev)}register(e){let t=Object.entries(e).filter(([,e])=>void 0!==e).map(([e,t])=>{!function(e,t){if("function"!=typeof e)throw Error(`Expected function for key "${t}", got ${typeof e}`)}(t,e);let n=this.sets.get(e);if(!n)throw Error(`Unknown callback key "${e}"`);return n.add(t)});return()=>{for(let e of t)e()}}compose(){return Object.fromEntries(Array.from(this.sets.entries()).filter(([,e])=>e.size>0).map(([e,t])=>[e,(...e)=>{t.invoke(...e)}]))}}function eC(e){let t=(0,eo.useRef)({}),n=c.filter(t=>void 0!==e[t]),o=n.join("|"),i=(0,eo.useMemo)(()=>Object.fromEntries(n.map(e=>[e,(...n)=>{let o=t.current[e];o?.(...n)}])),[o]);for(let n of c)t.current[n]=e[n];return i}let ew=[function({children:e}){let t=(0,eo.useContext)(es);if(!t)throw Error("ConversationControlsProvider must be rendered inside a ConversationProvider");let{conversationRef:n}=t,o=(0,eo.useCallback)(()=>{let e=n.current;if(!e)throw Error("No active conversation. Call startSession() first.");return e},[n]),i=(0,eo.useCallback)(e=>{o().sendUserMessage(e)},[o]),s=(0,eo.useCallback)(e=>{o().sendMultimodalMessage(e)},[o]),a=(0,eo.useCallback)(e=>o().uploadFile(e),[o]),r=(0,eo.useCallback)((e,t)=>{o().sendContextualUpdate(e,t)},[o]),l=(0,eo.useCallback)(()=>{o().sendUserActivity()},[o]),c=(0,eo.useCallback)((e,t)=>{o().sendMCPToolApprovalResult(e,t)},[o]),u=(0,eo.useCallback)(e=>{o().setVolume(e)},[o]),d=(0,eo.useCallback)(async e=>{let t=o();if(t instanceof et)return await t.changeInputDevice(e);throw Error("Device switching is only available for voice conversations")},[o]),h=(0,eo.useCallback)(async e=>{let t=o();if(t instanceof et)return await t.changeOutputDevice(e);throw Error("Device switching is only available for voice conversations")},[o]),p=(0,eo.useCallback)(()=>n.current?.getInputByteFrequencyData()??ec,[n]),m=(0,eo.useCallback)(()=>n.current?.getOutputByteFrequencyData()??ec,[n]),f=(0,eo.useCallback)(()=>n.current?.getInputVolume()??0,[n]),g=(0,eo.useCallback)(()=>n.current?.getOutputVolume()??0,[n]),v=(0,eo.useCallback)(()=>o().getId(),[o]),y=(0,eo.useMemo)(()=>({startSession:t.startSession,endSession:t.endSession,sendUserMessage:i,sendMultimodalMessage:s,uploadFile:a,sendContextualUpdate:r,sendUserActivity:l,sendMCPToolApprovalResult:c,setVolume:u,changeInputDevice:d,changeOutputDevice:h,getInputByteFrequencyData:p,getOutputByteFrequencyData:m,getInputVolume:f,getOutputVolume:g,getId:v}),[t.startSession,t.endSession,i,s,a,r,l,c,u,d,h,p,m,f,g,v]);return(0,ei.jsx)(eu.Provider,{value:y,children:e})},function({children:e}){let[t,n]=(0,eo.useState)("disconnected"),[o,i]=(0,eo.useState)(void 0);el({onStatusChange({status:e}){"disconnecting"!==e&&(n(e),i(void 0))},onError(e){n("error"),i(e)}});let s=(0,eo.useMemo)(()=>({status:t,message:o}),[t,o]);return(0,ei.jsx)(ed.Provider,{value:s,children:e})},function({children:e}){let[t,n]=(0,eo.useState)("listening");el({onModeChange({mode:e}){n(e)},onDisconnect(){n("listening")}});let o=(0,eo.useMemo)(()=>({mode:t,isSpeaking:"speaking"===t,isListening:"listening"===t}),[t]);return(0,ei.jsx)(em.Provider,{value:o,children:e})},function({children:e}){let t=er(),[n,o]=(0,eo.useState)(!1);el({onCanSendFeedbackChange({canSendFeedback:e}){o(e)},onDisconnect(){o(!1)}});let i=(0,eo.useCallback)((e,n)=>{t.current?.sendFeedback(e,n)},[t]),s=(0,eo.useMemo)(()=>({canSendFeedback:n,sendFeedback:i}),[n,i]);return(0,ei.jsx)(ef.Provider,{value:s,children:e})},function({children:e}){let t=(0,eo.useContext)(es);if(!t)throw Error("ConversationClientToolsProvider must be rendered inside a ConversationProvider");let{clientToolsRegistry:n,clientToolsRef:o}=t,i=(0,eo.useCallback)((e,t)=>{if(n.has(e))throw Error(`Client tool "${e}" is already registered by another hook. Each tool name must be unique.`);return n.set(e,t),o.current[e]=t,()=>{n.get(e)===t&&n.delete(e),o.current[e]===t&&delete o.current[e]}},[n,o]);return(0,ei.jsx)(eg.Provider,{value:i,children:e})}];function e_({children:e,isMuted:t,onMutedChange:n,...o}){let i=(0,eo.useRef)(null),a=(0,eo.useRef)(null),r=(0,eo.useRef)(0),l=(0,eo.useRef)(!1),[u]=(0,eo.useState)(()=>new Map),d=(0,eo.useRef)({}),h=(0,eo.useRef)(o);h.current=o;let[p]=(0,eo.useState)(()=>new ey(c)),[m,f]=(0,eo.useState)(null),g=eC(o),v=(0,eo.useCallback)(e=>p.register(e),[p]);(0,eo.useLayoutEffect)(()=>p.register({onDisconnect:()=>{i.current=null,f(null)}}),[p]);let y=(0,eo.useCallback)(e=>{if(i.current||a.current)return;l.current=!1;let t=++r.current,n=h.current,o=function(e="us"){switch(e){case"eu-residency":case"in-residency":case"us":case"global":return e;default:return console.warn(`[ElevenAgents] Invalid server-location: ${e}. Defaulting to "us"`),"us"}}(e?.serverLocation||n?.serverLocation),m={...n};for(let e of c)delete m[e];let v=function(...e){return function e(...t){return t.reduce((t,n)=>{let o={...t};for(let t of Object.keys(n)){let i=o[t],a=n[t];s(i)&&s(a)?o[t]=e(i,a):"function"==typeof i&&"function"==typeof a?o[t]=(...e)=>{i(...e),a(...e)}:void 0!==a&&(o[t]=a)}return o},{})}(...e)}({livekitUrl:{us:"wss://livekit.rtc.elevenlabs.io","eu-residency":"wss://livekit.rtc.eu.residency.elevenlabs.io","in-residency":"wss://livekit.rtc.in.residency.elevenlabs.io",global:"wss://livekit.rtc.elevenlabs.io"}[o]},m,g,p.compose(),e??{},{origin:{us:"wss://api.elevenlabs.io","eu-residency":"wss://api.eu.residency.elevenlabs.io","in-residency":"wss://api.in.residency.elevenlabs.io",global:"wss://api.elevenlabs.io"}[o]}),y=function(e,t){let n={...e};for(let[e,o]of t){if(Object.hasOwn(n,e))throw Error(`Client tool "${e}" is already provided via props/options. Remove it from props or do not register it with useConversationClientTool.`);n[e]=o}return n}(v.clientTools,u);d.current=y,v.clientTools=y;let C=v.onConversationCreated,w=()=>t!==r.current,_={...v,onConversationCreated:e=>{l.current||w()||(i.current=e,f(e),C?.(e))},onConnect:e=>{l.current||w()||(a.current=null,v.onConnect?.(e))}};a.current=en.startSession(_),a.current.then(e=>{if(!w()){if(l.current){e.endSession(),a.current=null;return}i.current!==e&&(i.current=e,f(e)),a.current=null}},e=>{if(w()||(i.current=null,f(null),a.current=null,l.current))return;let t=e instanceof Error?e.message:"Session failed to start";v.onError?.(t,e)})},[g,p,u,d]),C=(0,eo.useCallback)(()=>{l.current=!0;let e=a.current,t=i.current;i.current=null,f(null),e?e.then(e=>e.endSession(),()=>{}):t?.endSession()},[]);(0,eo.useEffect)(()=>()=>{l.current=!0,a.current?a.current.then(e=>e.endSession(),()=>{}):i.current?.endSession()},[]);let w=(0,eo.useMemo)(()=>({conversation:m,conversationRef:i,startSession:y,endSession:C,registerCallbacks:v,clientToolsRegistry:u,clientToolsRef:d}),[m,i,y,C,v,u,d]),_=ew.reduceRight((e,t)=>(0,ei.jsx)(t,{children:e}),(0,ei.jsx)(ep,{isMuted:t,onMutedChange:n,children:e}));return(0,ei.jsx)(es.Provider,{value:w,children:_})}function eb(e={}){let{micMuted:t,volume:n,...o}=e;el(eC(o));let i=(0,eo.useRef)(o);i.current=o;let s=function(){let e=(0,eo.useContext)(eu);if(!e)throw Error("useConversationControls must be used within a ConversationProvider");return e}(),{status:a,message:r}=function(){let e=(0,eo.useContext)(ed);if(!e)throw Error("useConversationStatus must be used within a ConversationProvider");return e}(),{isMuted:l,setMuted:u}=function(){let e=(0,eo.useContext)(eh);if(!e)throw Error("useConversationInput must be used within a ConversationProvider");return e}(),{mode:d,isSpeaking:h,isListening:p}=function(){let e=(0,eo.useContext)(em);if(!e)throw Error("useConversationMode must be used within a ConversationProvider");return e}(),{canSendFeedback:m,sendFeedback:f}=function(){let e=(0,eo.useContext)(ef);if(!e)throw Error("useConversationFeedback must be used within a ConversationProvider");return e}(),g=(0,eo.useCallback)(e=>{let t={...i.current};for(let e of c)delete t[e];s.startSession({...t,...e})},[s,i]),v=ea();return(0,eo.useEffect)(()=>{void 0!==t&&v&&u(t)},[t,v,u]),(0,eo.useEffect)(()=>{void 0!==n&&v&&v.setVolume({volume:n})},[n,v]),{...s,startSession:g,status:a,message:r,isMuted:t??l,setMuted:u,mode:d,isSpeaking:h,isListening:p,canSendFeedback:m,sendFeedback:f}}p=Object.freeze({name:"react_sdk",version:"1.10.1"})}}]);